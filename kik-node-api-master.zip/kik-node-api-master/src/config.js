module.exports = {
    kikVersionInfo: {version: "14.5.0.13136", sha1Digest: "LuYEjtvBu4mG2kBBG0wA3Ki1PSE="},
    device: {androidSdk: 19, model: "Samsung Galaxy S5 - 4.4.4 - API 19 - 1080x1920", brand: "generic", type: "android"}
};
