module.exports = () => {
    return({
        k: {
            _attributes: {
                anon: "1",
            }
        }
    });
};
